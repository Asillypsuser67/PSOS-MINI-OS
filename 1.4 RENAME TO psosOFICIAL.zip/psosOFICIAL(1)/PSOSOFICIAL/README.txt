README

To execute the SCRIPT open powershell and write this
powershell -ExecutionPolicy Bypass -File "$HOME\Downloads\PSOSOFICIAL.ps1"

Para ejecutar el código abre powershell y escribe esto
powershell -ExecutionPolicy Bypass -File "$HOME\Downloads\PSOSESP.ps1"


TOO,U CAN USE THE .EXE

TAMBIEN PUEDES USAR EL .EXE

IF U WANNA CREATE EXE USE THIS CODE IN POWERSHELL ADMIN
cd C:\Users\UUSER\Downloads
ps2exe ".\scriptname.ps1" ".\executablename.exe" -title "namedistribution" -product "nameofdistributionandversion" -company "urnick"

SI QUIERES CREAR UN EXE USA ESTE CODIGO EN POWERSHELL ADMINISTRADOR
cd C:\Users\TUUSUARIO\Downloads
ps2exe ".\TUNOMBREDESCRIPT.ps1" ".\NOMBREDELEXE.exe" -title "NOMBRE DE DISTRIBUCION" -product "NOMBREDEDISTRIBUCION Y SU VERSION" -company "TUALIAS"

Before, Dowload PS2EXE
Install-Module -Name ps2exe -Scope CurrentUser -Force
Antes, descarga PS2EXE
Install-Module -Name ps2exe -Scope CurrentUser -Force
