Clear-Host
$Global:UsuarioOS = "DonFulanito777"
$Global:OSVersion = "1.0.0-ArchStyle"
$Global:SistemaCorriendo = $true

Write-Host "=== PSOs ===" -ForegroundColor Gray
Start-Sleep -Seconds 1
Clear-Host

# 1. BLINDAJE DE INTEGRIDAD: Pantalla de Login de Ciberseguridad
Write-Host "=== PSOS SISTEMA DE SEGURIDAD ===" -ForegroundColor Red
$IntentoClave = Read-Host "root@mrfups_os login password"

if ($IntentoClave -ne "password") {
    Write-Host "ACCESO DENEGADO! CERRANDO SISTEMA..." -ForegroundColor Red
    Start-Sleep -Seconds 2
    exit
}

# 2. BUCLE PRINCIPAL DEL SISTEMA (Mantiene el entorno vivo)
while ($Global:SistemaCorriendo) {
    Clear-Host
    Write-Host "==================================================" -ForegroundColor Cyan
    Write-Host "  PSOs [1.0 $Global:OSVersion]            " -ForegroundColor Cyan
    Write-Host "  De nuevo aqui admin: $Global:UsuarioOS           " -ForegroundColor Green
    Write-Host "  Presiona 'help' para ver comandos disponibles" -ForegroundColor Yellow
    Write-Host "==================================================" -ForegroundColor Cyan
    Write-Host ""

    # Tu prompt interactivo estilo terminal de Linux/Arch
    $Comando = Read-Host "admin@mrfups_os:~#"

    switch ($Comando) {
        "help" {
            Write-Host ""
            Write-Host "  SYSINFO   - Shows PC space and OS specifications" -ForegroundColor White
            Write-Host "  JUGAR      - Launches your independent games" -ForegroundColor White
            Write-Host "  Limpiar     - Clears the screen buffer" -ForegroundColor White
            Write-Host "  NEOFETCH  - Displays system logo and specs" -ForegroundColor White
            Write-Host "  SALIR      - Shuts down the system completely" -ForegroundColor White
            Write-Host "MAnualbroWSER- Search in the internet like Wikipedia o Youtube" -ForegroundColor White
            $null = Read-Host "Press ENTER to continue"
        }
        "SYSINFO" {
            Clear-Host
            Write-Host "=== SYSTEM SPECIFICATIONS ===" -ForegroundColor Cyan
            Write-Host "OS NOMBRE:     PSOs" -ForegroundColor White
            Write-Host "ARQUITECTURA: 100% Indie CODIGO MEXICANO" -ForegroundColor Green
            Write-Host "ESTADO DE RAM:  UlTRA LIGERO (0% DE RAM USADO)" -ForegroundColor Green
            Write-Host "Security:    SmartScreen TRANSPARENTE (NO DONACIONES BLOQUEADAS)" -ForegroundColor Yellow
            Write-Host ""
            $null = Read-Host "PRESIONA ENTER PARA IR AL SHELL"
        }
        "NEOFETCH" {
            Clear-Host
            # Dibujamos tu personaje de la bola amarilla en arte ASCII con tu teclado
            Write-Host "     .---.     MRFUPS OS v$Global:OSVersion" -ForegroundColor Yellow
            Write-Host "    /     \    Kernel: POWERSHELL CORE" -ForegroundColor Yellow
            Write-Host "    | (o) |    Uptime: CONQUISTANDO INTERNET" -ForegroundColor Yellow
            Write-Host "    \     /    Shell: admin_terminal" -ForegroundColor Yellow
            Write-Host "     '---'     Location: [INFORMACION ENCRIPTADA]" -ForegroundColor Yellow
            Write-Host ""
            $null = Read-Host "PRESIONA ENTER PARA IR AL SHELL"
        }
        
        "JUGAR" {
            Clear-Host
            Write-Host "=== PSOs CARGADOR DE JUEGOS ===" -ForegroundColor Magenta
            Write-Host "1. Trivia Game (DEDICADO POR SILLYPOWERSHELL)" -ForegroundColor White
            Write-Host "2. BFDIA 5B (yea bro)" -ForegroundColor White
            Write-Host "3. TRIVIACRACK (SOLO CON INTERNET)" -ForegroundColor White
            Write-Host ""
            $SubJuego = Read-Host "SELECIONA UN JUEGO PARA JUGAR XD"
 
            switch ($SubJuego) {
                "1" { Write-Host "CARGANDO TRIVIA..." -ForegroundColor Green
                 
                $RutaPSOS = "$HOME\Downloads\PSOS\lol2.exe"
                Write-Host "ABRIENDO EL JUEGO..." -ForegroundColor Green
                Start-Process $RutaPSOS
            }
                "2" { Write-Host "CARGANDO BFDIA 5B... [EL GRAN FINAL SE ACERCA]" -ForegroundColor Yellow
                 Start-Process "https://www.numuki.com/game/bfdia-5b/" 
            }
                
                "3" { Write-Host "INICIANDO PAGINA WEB..." -ForegroundColor Red
                Start-Process "https://triviacrack.com/#splash"
            }
          }
            Read-Host "PRESIONA ENTER PARA IR AL OS"
        }
        "clear" {
            # Borrador mágico nativo
            Clear-Host
        }
        "exit" {
            Write-Host "¡CERRANDO EL OS,CHAO BRO!" -ForegroundColor Yellow
            Start-Sleep -Seconds 1
            $Global:SistemaCorriendo = $false
           } 
            
            "MAnualbroWSER" {
            Clear-Host
            Write-Host "=== ESCRIBE EJEMPLO: `Start-Process ''CUALQUIERWWW'' ===" -ForegroundColor Green
             $ComandoManual = Read-Host "PSOs:admin# "
             if (-not [string]::IsNullOrWhiteSpace($ComandoManual)) { 
                try { 
                    Invoke-Expression $ComandoManual
                Write-Host "`n[System OK] EXECUTANDO" -ForegroundColor Green } 
                catch { 
                Write-Host "[ERROR] CHECA COMO LO ESCRIBISTES." -ForegroundColor Red } }
              Read-Host "PRESIONA ENTER PARA IR AL OS" 
            }
        Default {
            Write-Host "Command '$Comando' NO RECONOCIDO. PRESIONA 'help' PARA VER MAS COMANDO." -ForegroundColor Red
            Start-Sleep -Seconds 1
        }
    }
   }
# El freno máster que evita el apagón automático del ejecutable .exe
Read-Host "PSOS CIERRA, PRESIONA ENTER PARA SALIR DEL OS"