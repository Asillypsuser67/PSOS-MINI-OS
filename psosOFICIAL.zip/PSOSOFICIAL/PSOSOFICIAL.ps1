Clear-Host
$Global:UsuarioOS = "DonFulanito777"
$Global:OSVersion = "1.0.0-ArchStyle"
$Global:SistemaCorriendo = $true

Write-Host "=== PSOs ===" -ForegroundColor Gray
Start-Sleep -Seconds 1
Clear-Host

# 1. BLINDAJE DE INTEGRIDAD: Pantalla de Login de Ciberseguridad
Write-Host "=== MRFUPS SECURITY SYSTEM ===" -ForegroundColor Red
$IntentoClave = Read-Host "root@mrfups_os login password"

if ($IntentoClave -ne "password") {
    Write-Host "ACCESS DENIED! SHUTTING DOWN SYSTEM..." -ForegroundColor Red
    Start-Sleep -Seconds 2
    exit
}

# 2. BUCLE PRINCIPAL DEL SISTEMA (Mantiene el entorno vivo)
while ($Global:SistemaCorriendo) {
    Clear-Host
    Write-Host "==================================================" -ForegroundColor Cyan
    Write-Host "  PSOs [Version $Global:OSVersion]            " -ForegroundColor Cyan
    Write-Host "  Welcome back, admin: $Global:UsuarioOS           " -ForegroundColor Green
    Write-Host "  Type 'help' to see the available system commands" -ForegroundColor Yellow
    Write-Host "==================================================" -ForegroundColor Cyan
    Write-Host ""

    # Tu prompt interactivo estilo terminal de Linux/Arch
    $Comando = Read-Host "admin@mrfups_os:~#"

    switch ($Comando) {
        "help" {
            Write-Host ""
            Write-Host "  sysinfo   - Shows PC space and OS specifications" -ForegroundColor White
            Write-Host "  play      - Launches your independent games" -ForegroundColor White
            Write-Host "  clear     - Clears the screen buffer" -ForegroundColor White
            Write-Host "  neofetch  - Displays system logo and specs" -ForegroundColor White
            Write-Host "  exit      - Shuts down the system completely" -ForegroundColor White
            Write-Host "MAnualbroWSER- Search in the internet like Wikipedia o Youtube" -ForegroundColor White
            $null = Read-Host "Press ENTER to continue"
        }
        "sysinfo" {
            Clear-Host
            Write-Host "=== SYSTEM SPECIFICATIONS ===" -ForegroundColor Cyan
            Write-Host "OS Name:     PSOs" -ForegroundColor White
            Write-Host "Architecture: 100% Indie Mexican Code" -ForegroundColor Green
            Write-Host "RAM Status:  Ultra Light (Consumes 0% RAM)" -ForegroundColor Green
            Write-Host "Security:    SmartScreen Transparent (No Donates Lock)" -ForegroundColor Yellow
            Write-Host ""
            $null = Read-Host "Press ENTER to return to shell"
        }
        "neofetch" {
            Clear-Host
            # Dibujamos tu personaje de la bola amarilla en arte ASCII con tu teclado
            Write-Host "     .---.     MRFUPS OS v$Global:OSVersion" -ForegroundColor Yellow
            Write-Host "    /     \    Kernel: PowerShell Core" -ForegroundColor Yellow
            Write-Host "    | (o) |    Uptime: Conquering internet" -ForegroundColor Yellow
            Write-Host "    \     /    Shell: admin_terminal" -ForegroundColor Yellow
            Write-Host "     '---'     Location: [ENCRIPTED INFORMATION]" -ForegroundColor Yellow
            Write-Host ""
            $null = Read-Host "Press ENTER to return to shell"
        }
        
        "play" {
            Clear-Host
            Write-Host "=== PSOs GAME LOADER ===" -ForegroundColor Magenta
            Write-Host "1. Trivia Game (SillyPower Dedicated)" -ForegroundColor White
            Write-Host "2. BFDIA 5B (yea)" -ForegroundColor White
            Write-Host "3. TRIVIACRACK (only with internet)" -ForegroundColor White
            Write-Host ""
            $SubJuego = Read-Host "Select a game to execute"
 
            switch ($SubJuego) {
                "1" { Write-Host "Launching Trivia..." -ForegroundColor Green
                 
                $RutaPSOS = "$HOME\Downloads\PSOS\lol2.exe"
                Write-Host "OPENING THE GAME..." -ForegroundColor Green
                Start-Process $RutaPSOS
            }
                "2" { Write-Host "Loading BFDIA 5B... [The Grand Finale is coming]" -ForegroundColor Yellow
                 Start-Process "https://www.numuki.com/game/bfdia-5b/" 
            }
                
                "3" { Write-Host "Initializing WEB PAGE..." -ForegroundColor Red
                Start-Process "https://triviacrack.com/#splash"
            }
          }
            Read-Host "Press Enter to return to OS"
        }
        "clear" {
            # Borrador mágico nativo
            Clear-Host
        }
        "exit" {
            Write-Host "Closing core modules... Goodbye bro!" -ForegroundColor Yellow
            Start-Sleep -Seconds 1
            $Global:SistemaCorriendo = $false
           } 
            
            "MAnualbroWSER" {
            Clear-Host
            Write-Host "=== WRITE `Start-Process ''anylinkcomplet'' ===" -ForegroundColor Green
             $ComandoManual = Read-Host "PSOs:admin# "
             if (-not [string]::IsNullOrWhiteSpace($ComandoManual)) { 
                try { 
                    Invoke-Expression $ComandoManual
                Write-Host "`n[System OK] EXECUTING." -ForegroundColor Green } 
                catch { 
                Write-Host "`n[ERROR] Check how u search lol." -ForegroundColor Red } }
              Read-Host "Press enter to return to OS" 
            }
        Default {
            Write-Host "Command '$Comando' not recognized. Type 'help' for info." -ForegroundColor Red
            Start-Sleep -Seconds 1
        }
    }
   }
# El freno máster que evita el apagón automático del ejecutable .exe
Read-Host "PSOS Shuts Down. Press ENTER to close terminal"